package com.hostel.hms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Hostel1ApplicationTests {

	@Test
	void contextLoads() {
	}

}

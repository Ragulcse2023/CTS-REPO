package com.hostel.hms.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;
import lombok.ToString;




@Entity
@ToString
public @Data class Feedback {
    @Id
    @Column
    @NotBlank(message = "Name is required")
    private String name;

    @NotBlank(message = "Email is required")
    @Email(message = "Invalid email format")
    @Column
    private String email;

    @NotBlank(message = "Feedback is required")
    @Column
    private String feedback;

}

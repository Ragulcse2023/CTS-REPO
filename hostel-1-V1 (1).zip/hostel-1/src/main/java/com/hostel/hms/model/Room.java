package com.hostel.hms.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Entity
public  @Data class Room {

	
	
	@Id
	@Column
	@NotNull(message="Room number  required")
	private int roomno;
	
	
	@Column
	@NotNull(message="Room type must be   required")
	private String roomtype;
	
	@Column
	@NotNull(message="Room capacity is required")
	private int capacity;
	
	@Column
	@NotNull(message="Availability must required")
	private boolean availability;
	
	@Column
	private int fees;
}

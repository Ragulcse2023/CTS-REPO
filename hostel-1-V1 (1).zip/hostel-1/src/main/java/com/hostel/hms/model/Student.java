package com.hostel.hms.model;

import java.sql.Date;

import org.hibernate.validator.constraints.Range;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
@Entity
public @Data class Student {
	//use validating api 
	@Id
	@Column()
	@NotNull(message="Stduent ID must")
	private int stuid;
	@NotNull(message ="Name Required")
	private String name;
	@NotNull(message ="Age Required")
	@Range(min = 18,max =100)
	private int age;
	@Column
	private String gender;
	@NotNull(message ="Date Must Be in  format of DD/MM/YYYY")
	@Column
	private Date dob;
	@NotNull(message ="Address  Required")
	@Column
	private String address;
	@NotNull(message ="Mobile Number is  Required")
	@Range(min=12,message="Mobile Number must be 10 digits")
	@Column
	private long mobile;
	@NotNull(message ="Email must be  Required")
	@Email(message="Email must be in format of abc@gmail.com")
	@Column
	private String email;
	@NotNull(message ="Aadhar must  Required")
	@Range(min=12)
	@Column
	private long aadhar;
	@NotNull(message ="Name Required")
	@Column
	private String gname;
	@NotNull(message ="Name Required")
	@Column
	private long gmobile;
	@NotNull(message ="Address Required")
	@Column
	private String gaddress;
	@NotNull(message ="Room number  Required")
	@Column
	private int roomno;
	@NotNull(message ="Date Need to be choosen")
	@Column
	private Date doj;
}

package com.hostel.hms.model;

import java.sql.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
@Entity
public @Data class OldStudent {
	//use validatuin api 
	@Id
	@Column()
	private int stuid;
	@NotNull(message ="Not Null")
	private String name;
	@NotNull
	private int age;
	@NotNull
	@Column
	private String gender;
	@NotNull
	@Column
	private Date dob;
	@NotNull
	@Column
	private String address;
	@NotNull
	@Column
	private long mobile;
	@NotNull
	@Column
	private String email;
	@NotNull
	@Column
	private long aadhar;
	@NotNull
	@Column
	private String gname;
	@NotNull
	@Column
	private long gmobile;
	@NotNull
	@Column
	private String gaddress;
	@NotNull
	@Column
	private int roomno;
	@NotNull
	@Column
	private Date doj;
	@Column
	private Date dor;
}

